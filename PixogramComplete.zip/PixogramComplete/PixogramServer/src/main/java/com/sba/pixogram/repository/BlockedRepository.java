package com.sba.pixogram.repository;

import org.springframework.data.repository.CrudRepository;

import com.sba.pixogram.entity.Blocked;

public interface BlockedRepository extends CrudRepository<Blocked, Long>{

}
