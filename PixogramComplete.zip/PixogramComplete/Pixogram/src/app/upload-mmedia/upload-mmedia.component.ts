import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-upload-mmedia',
  templateUrl: './upload-mmedia.component.html',
  styleUrls: ['./upload-mmedia.component.css']
})
export class UploadMMediaComponent implements OnInit {

  constructor(public userservice:UserService) { }

  ngOnInit() {
  }

}
